(function () {
  "use strict";

  /* =========================================================
     HELPER FUNCTIONS
     ========================================================= */

  const $ = (selector) => document.querySelector(selector);

  const $$ = (selector) =>
    Array.from(document.querySelectorAll(selector));


  const state = {
    order: null,
    selectedItems: new Set()
  };


  const DEMO_EMAIL_NOTE =
    "For this demo, any valid email format is accepted.";


  function daysAgo(days) {
    const date = new Date();

    date.setDate(
      date.getDate() - days
    );

    return date;
  }


  function formatDate(date) {
    if (!date) {
      return "Unknown";
    }

    return new Intl.DateTimeFormat(
      "en-US",
      {
        month: "short",
        day: "numeric",
        year: "numeric"
      }
    ).format(date);
  }


  function dayDiff(laterDate, earlierDate) {
    return Math.floor(
      (laterDate - earlierDate) / 86400000
    );
  }


  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }


  /* =========================================================
     DEMO ORDER DATABASE
     ========================================================= */

  const DEMO_ORDERS = {

    "NS-1001": {
      status: "Delivered",

      deliveredDate: daysAgo(5),

      items: [

        {
          id: "item-jacket",
          name: "Aria Rain Jacket",
          sku: "ARA-JKT-M",
          price: 89.0,
          finalSale: false,
          returnable: true
        },

        {
          id: "item-giftcard",
          name: "Northstar Gift Card",
          sku: "GC-25",
          price: 25.0,
          finalSale: true,
          returnable: false
        },

        {
          id: "item-tee",
          name: "Everyday Crew Tee",
          sku: "TEE-M-BLK",
          price: 19.0,
          finalSale: false,
          returnable: true
        }

      ]
    },


    "NS-1002": {
      status: "Delivered",

      deliveredDate: daysAgo(41),

      items: [

        {
          id: "item-socks",
          name: "Trail Socks",
          sku: "SOCK-L",
          price: 12.0,
          finalSale: false,
          returnable: true
        }

      ]
    },


    "NS-1003": {
      status: "Cancelled",

      deliveredDate: null,

      items: []
    }

  };


  /* =========================================================
     DEMO REFUND DATABASE
     ========================================================= */

  const REFUND_RECORDS = {

    "NS-1001": {

      returnId: "RET-4482",

      statusMessage:
        "Return received; inspection pending",

      refundAmount: 108.0,

      method: "Visa ending 4242",

      slaMessage:
        "Inspection usually takes up to 2 business days. Once approved, card refunds usually appear within 5–10 business days.",

      timeline: [

        {
          label: "Return requested",
          date: daysAgo(6),
          complete: true,
          pending: false,
          sla: ""
        },

        {
          label: "Return in transit",
          date: daysAgo(4),
          complete: true,
          pending: false,
          sla: ""
        },

        {
          label: "Received at warehouse",
          date: daysAgo(2),
          complete: true,
          pending: false,
          sla: ""
        },

        {
          label: "Inspection",
          date: null,
          complete: false,
          pending: true,
          sla: "Up to 2 business days"
        },

        {
          label: "Refund issued",
          date: null,
          complete: false,
          pending: false,
          sla: "After inspection approval"
        }

      ]

    },


    "NS-1003": {

      returnId: "REF-9931",

      statusMessage:
        "Refund issued",

      refundAmount: 54.0,

      method: "Visa ending 4242",

      slaMessage:
        "Your refund was issued. Depending on your bank, card refunds can take 5–10 business days to appear.",

      timeline: [

        {
          label: "Order cancelled",
          date: daysAgo(3),
          complete: true,
          pending: false,
          sla: ""
        },

        {
          label: "Refund issued",
          date: daysAgo(2),
          complete: true,
          pending: false,
          sla: ""
        },

        {
          label: "Bank processing",
          date: null,
          complete: false,
          pending: true,
          sla: "5–10 business days"
        }

      ]

    }

  };


  /* =========================================================
     TABS
     ========================================================= */

  const tabs = $$('[role="tab"]');


  function activateTab(tab) {

    tabs.forEach((item) => {

      const isSelected =
        item === tab;

      item.setAttribute(
        "aria-selected",
        String(isSelected)
      );

      item.tabIndex =
        isSelected ? 0 : -1;


      const panel =
        document.getElementById(
          item.getAttribute("aria-controls")
        );


      if (panel) {
        panel.hidden = !isSelected;
      }

    });


    tab.focus();
  }


  tabs.forEach((tab, index) => {

    tab.addEventListener(
      "click",
      () => activateTab(tab)
    );


    tab.addEventListener(
      "keydown",
      (event) => {

        let target = null;


        if (event.key === "ArrowRight") {
          target =
            tabs[(index + 1) % tabs.length];
        }


        if (event.key === "ArrowLeft") {
          target =
            tabs[
              (index - 1 + tabs.length) %
              tabs.length
            ];
        }


        if (event.key === "Home") {
          target = tabs[0];
        }


        if (event.key === "End") {
          target =
            tabs[tabs.length - 1];
        }


        if (target) {

          event.preventDefault();

          activateTab(target);

        }

      }
    );

  });


  /* =========================================================
     ALERT SYSTEM
     ========================================================= */

  function showAlert(
    selector,
    message,
    type
  ) {

    const alertBox =
      $(selector);


    if (!alertBox) {
      return;
    }


    alertBox.className =
      "alert " + type;


    alertBox.innerHTML =
      message;


    alertBox.hidden = false;
  }


  function hideAlert(selector) {

    const alertBox =
      $(selector);


    if (!alertBox) {
      return;
    }


    alertBox.hidden = true;

    alertBox.innerHTML = "";
  }


  /* =========================================================
     SUPPORT ESCALATION
     ========================================================= */

  function createSupportReference() {

    return (
      "SUP-" +
      Math.floor(
        100000 +
        Math.random() * 900000
      )
    );

  }


  function escalate(
    kind,
    reason
  ) {

    const reference =
      createSupportReference();


    const targetSelector =
      kind === "return"
        ? "#returnEscalation"
        : "#refundEscalation";


    const message =
      "<strong>Support request created.</strong> " +
      "Reference " +
      reference +
      ". " +
      reason +
      " The support team will receive the order context, selected controls, and decision path from this page.";


    showAlert(
      targetSelector,
      message,
      "warning"
    );


    $(targetSelector).scrollIntoView({
      behavior: "smooth",
      block: "nearest"
    });

  }


  /* =========================================================
     RETURN ORDER LOOKUP
     ========================================================= */

  function lookupReturnOrder() {

    hideAlert("#lookupError");

    hideAlert("#orderStatusAlert");

    hideAlert("#returnFormAlert");

    hideAlert("#returnEscalation");


    $("#returnResult").hidden = true;

    $("#returnAudit").hidden = true;

    $("#escalateReturnBtn").hidden = true;


    const orderNumber =
      $("#returnOrderNumber")
        .value
        .trim()
        .toUpperCase();


    const email =
      $("#returnEmail")
        .value
        .trim();


    if (!orderNumber) {

      showAlert(
        "#lookupError",
        "Please enter your order number.",
        "error"
      );

      return;
    }


    if (!isValidEmail(email)) {

      showAlert(
        "#lookupError",
        "Please enter a valid email address. " +
        DEMO_EMAIL_NOTE,
        "error"
      );

      return;
    }


    const order =
      DEMO_ORDERS[orderNumber];


    if (!order) {

      state.order = null;

      state.selectedItems.clear();

      $("#orderSummary").hidden = true;

      $("#returnDetails").hidden = true;


      showAlert(
        "#lookupError",
        "We could not find that order. For the demo, use <strong>NS-1001</strong>, <strong>NS-1002</strong>, or <strong>NS-1003</strong>.",
        "error"
      );

      return;
    }


    state.order = order;

    state.selectedItems.clear();


    renderOrderSummary(
      orderNumber,
      order
    );

  }


  /* =========================================================
     ORDER SUMMARY
     ========================================================= */

  function renderOrderSummary(
    orderNumber,
    order
  ) {

    $("#orderSummary").hidden =
      false;


    $("#summaryOrderNumber")
      .textContent =
      orderNumber;


    $("#summaryOrderStatus")
      .textContent =
      order.status;


    $("#summaryDeliveredDate")
      .textContent =
      order.deliveredDate
        ? formatDate(
            order.deliveredDate
          )
        : "Not delivered";


    $("#summaryReturnWindow")
      .textContent =
      order.deliveredDate
        ? "30 days from delivery for most items"
        : "Starts after delivery";


    const itemSelection =
      $("#itemSelection");


    const returnDetails =
      $("#returnDetails");


    const orderStatusAlert =
      $("#orderStatusAlert");


    hideAlert(
      "#orderStatusAlert"
    );


    /* CANCELLED ORDER */

    if (
      order.status ===
      "Cancelled"
    ) {

      itemSelection.hidden = true;

      returnDetails.hidden = true;


      orderStatusAlert.className =
        "alert info";


      orderStatusAlert.hidden =
        false;


      orderStatusAlert.innerHTML =
        "This order was cancelled. If you are waiting for money to return, use the refund status flow." +
        '<div class="actions">' +
        '<button type="button" id="cancelledToRefundBtn" class="secondary">' +
        "Check refund status" +
        "</button>" +
        "</div>";


      $("#cancelledToRefundBtn")
        .addEventListener(
          "click",
          () => {
            activateTab(
              $("#tab-refund")
            );
          }
        );


      return;
    }


    /* NON-DELIVERED */

    if (
      order.status !==
      "Delivered"
    ) {

      itemSelection.hidden = true;

      returnDetails.hidden = true;


      orderStatusAlert.className =
        "alert warning";


      orderStatusAlert.hidden =
        false;


      orderStatusAlert.textContent =
        "Returns usually begin after delivery. If the delivery date is missing or incorrect, support should verify the order before a return is started.";


      return;
    }


    /* NO ITEMS */

    if (!order.items.length) {

      itemSelection.hidden = true;

      returnDetails.hidden = true;


      orderStatusAlert.className =
        "alert info";


      orderStatusAlert.hidden =
        false;


      orderStatusAlert.textContent =
        "No returnable items are shown for this order.";


      return;
    }


    /* NORMAL ORDER */

    itemSelection.hidden = false;

    returnDetails.hidden = false;


    renderItems(order);


    if (
      order.deliveredDate &&
      dayDiff(
        new Date(),
        order.deliveredDate
      ) > 30
    ) {

      showAlert(
        "#orderStatusAlert",
        "This order appears to be outside the standard 30-day return window. Damaged, defective, or wrong-item issues may still be reviewed under the shorter issue-reporting window.",
        "warning"
      );

    }

  }


  /* =========================================================
     RENDER ITEMS
     ========================================================= */

  function renderItems(order) {

    const itemList =
      $("#itemList");


    itemList.innerHTML = "";


    order.items.forEach(
      (item) => {

        const card =
          document.createElement(
            "label"
          );


        card.className =
          "item-card" +
          (
            item.returnable
              ? ""
              : " disabled"
          );


        const badges = [];


        if (item.finalSale) {

          badges.push(
            '<span class="pill final">Final sale</span>'
          );

        }


        if (!item.returnable) {

          badges.push(
            '<span class="pill nonreturnable">Non-returnable</span>'
          );

        } else {

          badges.push(
            '<span class="pill returnable">Returnable</span>'
          );

        }


        card.innerHTML =

          '<input type="checkbox" value="' +
          item.id +
          '"' +
          (
            item.returnable
              ? ""
              : " disabled"
          ) +
          " />" +

          '<span class="item-name">' +
          item.name +
          "</span>" +

          '<span class="item-meta">' +
          item.sku +
          " · $" +
          item.price.toFixed(2) +
          "</span>" +

          '<span class="badge-container">' +
          badges.join("") +
          "</span>";


        const checkbox =
          card.querySelector(
            "input"
          );


        if (item.returnable) {

          checkbox.addEventListener(
            "change",
            (event) => {

              if (
                event.target.checked
              ) {

                state.selectedItems.add(
                  item.id
                );

              } else {

                state.selectedItems.delete(
                  item.id
                );

              }

            }
          );

        }


        itemList.appendChild(card);

      }
    );

  }


  /* =========================================================
     RETURN ELIGIBILITY RULE ENGINE
     ========================================================= */

  function evaluateReturnEligibility(
    order,
    selectedIds,
    reason,
    condition
  ) {

    const selectedItems =
      order.items.filter(
        (item) =>
          selectedIds.includes(
            item.id
          )
      );


    const isIssue =
      reason ===
        "damaged_defective" ||
      reason ===
        "wrong_item";


    const daysSinceDelivery =
      order.deliveredDate
        ? dayDiff(
            new Date(),
            order.deliveredDate
          )
        : null;


    /* RET-005 */

    if (
      daysSinceDelivery === null
    ) {

      return {

        eligible: false,

        rule: "RET-005",

        escalate: true,

        message:
          "The delivery date is unavailable, so support must verify the return window."

      };

    }


    /* RET-007 */

    if (
      isIssue &&
      daysSinceDelivery > 14
    ) {

      return {

        eligible: false,

        rule: "RET-007",

        escalate: true,

        message:
          "Damaged, defective, or wrong-item reports must usually be made within 14 days of delivery. Support can review possible exceptions."

      };

    }


    /* RET-010 */

    if (
      !isIssue &&
      daysSinceDelivery > 30
    ) {

      return {

        eligible: false,

        rule: "RET-010",

        escalate: true,

        message:
          "This order is outside the standard 30-day return window."

      };

    }


    /* RET-008 */

    if (
      selectedItems.some(
        (item) =>
          item.finalSale &&
          !isIssue
      )
    ) {

      return {

        eligible: false,

        rule: "RET-008",

        escalate: false,

        message:
          "One or more selected items are final sale and cannot be returned for this reason."

      };

    }


    /* RET-009 */

    if (
      selectedItems.some(
        (item) =>
          !item.returnable &&
          !isIssue
      )
    ) {

      return {

        eligible: false,

        rule: "RET-009",

        escalate: false,

        message:
          "One or more selected items are non-returnable."

      };

    }


    /* RET-011 */

    if (
      !isIssue &&
      condition !==
        "unused_original"
    ) {

      return {

        eligible: false,

        rule: "RET-011",

        escalate: true,

        message:
          "Standard returns must be unused and in original packaging. Support can review possible exceptions."

      };

    }


    /* RET-011 */

    if (
      isIssue &&
      condition ===
        "used_or_opened"
    ) {

      return {

        eligible: false,

        rule: "RET-011",

        escalate: true,

        message:
          "Because the item appears used or opened, support must review the return."

      };

    }


    /* ELIGIBLE */

    return {

      eligible: true,

      rule:
        isIssue
          ? "RET-006"
          : "RET-012",

      escalate: false,

      message:
        "Eligible for return."

    };

  }


  /* =========================================================
     SUBMIT RETURN
     ========================================================= */

  function submitReturnForm(event) {

    event.preventDefault();


    hideAlert(
      "#returnFormAlert"
    );

    hideAlert(
      "#returnEscalation"
    );


    $("#returnResult").hidden =
      true;


    $("#returnAudit").hidden =
      true;


    $("#escalateReturnBtn").hidden =
      true;


    if (!state.order) {

      showAlert(
        "#returnFormAlert",
        "Please find your order before starting a return.",
        "error"
      );

      return;
    }


    const selectedIds =
      Array.from(
        state.selectedItems
      );


    if (!selectedIds.length) {

      showAlert(
        "#returnFormAlert",
        "Please select at least one returnable item.",
        "error"
      );

      return;
    }


    const reason =
      $("#returnReason").value;


    if (!reason) {

      showAlert(
        "#returnFormAlert",
        "Please select a return reason.",
        "error"
      );

      return;
    }


    const condition =
      document.querySelector(
        'input[name="condition"]:checked'
      );


    if (!condition) {

      showAlert(
        "#returnFormAlert",
        "Please select the item condition.",
        "error"
      );

      return;
    }


    const resolution =
      $("#resolution").value;


    if (!resolution) {

      showAlert(
        "#returnFormAlert",
        "Please select a preferred resolution.",
        "error"
      );

      return;
    }


    const returnMethod =
      document.querySelector(
        'input[name="returnMethod"]:checked'
      );


    if (!returnMethod) {

      showAlert(
        "#returnFormAlert",
        "Please select a return method.",
        "error"
      );

      return;
    }


    if (
      !$("#policyConfirm").checked
    ) {

      showAlert(
        "#returnFormAlert",
        "Please confirm the return policy statement before continuing.",
        "error"
      );

      return;
    }


    const decision =
      evaluateReturnEligibility(
        state.order,
        selectedIds,
        reason,
        condition.value
      );


    const auditPayload = {

      task: "10",

      page:
        "Returns & Refunds",

      timestamp:
        new Date().toISOString(),

      orderNumber:
        $("#returnOrderNumber")
          .value
          .trim()
          .toUpperCase(),

      selectedItems:
        selectedIds,

      reason:
        reason,

      condition:
        condition.value,

      resolution:
        resolution,

      returnMethod:
        returnMethod.value,

      policyConfirmed:
        true,

      decision:
        decision

    };


    /* INELIGIBLE */

    if (!decision.eligible) {

      showAlert(
        "#returnFormAlert",

        decision.message +
          '<br /><span class="rule-ref">Decision rule: ' +
          decision.rule +
          "</span>",

        "error"
      );


      if (decision.escalate) {

        $("#escalateReturnBtn")
          .hidden = false;

      }


      return;
    }


    /* ELIGIBLE */

    const returnId =
      "RET-" +
      Math.floor(
        100000 +
        Math.random() * 900000
      );


    const selectedNames =
      state.order.items

        .filter(
          (item) =>
            selectedIds.includes(
              item.id
            )
        )

        .map(
          (item) =>
            item.name
        )

        .join(", ");


    const nextStep =
      returnMethod.value ===
      "mail"

        ? "Use the prepaid mail label instructions sent to your email."

        : "Bring the item to a Northstar drop-off location, if available.";


    const refundEstimate =
      resolution ===
      "original_payment"

        ? "After warehouse receipt and inspection, card refunds usually take 5–10 business days to appear."

        : "After warehouse receipt and inspection, store credit is usually available within 24 hours.";


    $("#returnResult").hidden =
      false;


    $("#returnResult").innerHTML =

      "<strong>Return started successfully.</strong><br />" +

      "Return ID: <strong>" +
      returnId +
      "</strong><br />" +

      "Items: " +
      selectedNames +
      "<br />" +

      "Next step: " +
      nextStep +
      "<br />" +

      "Refund estimate: " +
      refundEstimate +
      "<br />" +

      '<span class="rule-ref">Decision rule: ' +
      decision.rule +
      "</span>";


    $("#returnAuditBody")
      .textContent =
      JSON.stringify(
        auditPayload,
        null,
        2
      );


    $("#returnAudit").hidden =
      false;


    $("#returnResult")
      .scrollIntoView({
        behavior: "smooth",
        block: "nearest"
      });

  }


  /* =========================================================
     REFUND STATUS LOOKUP
     ========================================================= */

  function lookupRefundStatus() {

    hideAlert(
      "#refundLookupError"
    );

    hideAlert(
      "#refundEscalation"
    );


    $("#refundResult").hidden =
      true;


    $("#refundNoRecord").hidden =
      true;


    const orderNumber =
      $("#refundOrderNumber")
        .value
        .trim()
        .toUpperCase();


    const email =
      $("#refundEmail")
        .value
        .trim();


    if (!orderNumber) {

      showAlert(
        "#refundLookupError",
        "Please enter your order number.",
        "error"
      );

      return;
    }


    if (!isValidEmail(email)) {

      showAlert(
        "#refundLookupError",
        "Please enter a valid email address. " +
        DEMO_EMAIL_NOTE,
        "error"
      );

      return;
    }


    const order =
      DEMO_ORDERS[
        orderNumber
      ];


    const refundRecord =
      REFUND_RECORDS[
        orderNumber
      ];


    if (!order) {

      showAlert(
        "#refundLookupError",

        "We could not find that order. For the demo, use <strong>NS-1001</strong> or <strong>NS-1003</strong>.",

        "error"
      );

      return;
    }


    if (!refundRecord) {

      $("#refundNoRecordText")
        .textContent =
        "We found order " +
        orderNumber +
        ", but no refund or return record is attached yet. If the order was delivered, start a return first.";


      $("#refundNoRecord")
        .hidden = false;


      return;
    }


    renderRefundRecord(
      refundRecord
    );

  }


  /* =========================================================
     REFUND RECORD
     ========================================================= */

  function renderRefundRecord(
    record
  ) {

    $("#refundResult")
      .hidden = false;


    $("#refundId")
      .textContent =
      record.returnId;


    $("#refundStatusMessage")
      .textContent =
      record.statusMessage;


    $("#refundAmount")
      .textContent =
      "$" +
      record.refundAmount.toFixed(2);


    $("#refundMethod")
      .textContent =
      record.method;


    $("#refundSla")
      .textContent =
      record.slaMessage;


    const timeline =
      $("#refundTimeline");


    timeline.innerHTML = "";


    record.timeline.forEach(
      (step) => {

        const listItem =
          document.createElement(
            "li"
          );


        if (step.complete) {

          listItem.classList.add(
            "complete"
          );

        } else if (step.pending) {

          listItem.classList.add(
            "pending"
          );

        }


        const dateText =
          step.date
            ? formatDate(
                step.date
              )
            : step.sla ||
              "Pending";


        listItem.innerHTML =

          '<span class="timeline-label">' +
          step.label +
          "</span>" +

          '<span class="timeline-date">' +
          dateText +
          "</span>";


        timeline.appendChild(
          listItem
        );

      }
    );

  }


  /* =========================================================
     EVENT LISTENERS
     ========================================================= */

  $("#lookupOrderBtn")
    .addEventListener(
      "click",
      lookupReturnOrder
    );


  [
    "#returnOrderNumber",
    "#returnEmail"
  ].forEach(
    (selector) => {

      $(selector)
        .addEventListener(
          "keydown",
          (event) => {

            if (
              event.key ===
              "Enter"
            ) {

              event.preventDefault();

              lookupReturnOrder();

            }

          }
        );

    }
  );


  $("#refundLookupBtn")
    .addEventListener(
      "click",
      lookupRefundStatus
    );


  [
    "#refundOrderNumber",
    "#refundEmail"
  ].forEach(
    (selector) => {

      $(selector)
        .addEventListener(
          "keydown",
          (event) => {

            if (
              event.key ===
              "Enter"
            ) {

              event.preventDefault();

              lookupRefundStatus();

            }

          }
        );

    }
  );


  /* RETURN REASON */

  $("#returnReason")
    .addEventListener(
      "change",
      (event) => {

        const issueReasons = [
          "damaged_defective",
          "wrong_item"
        ];


        $("#photoUpload")
          .hidden =
          !issueReasons.includes(
            event.target.value
          );


        hideAlert(
          "#returnFormAlert"
        );

      }
    );


  /* PHOTO UPLOAD */

  $("#photos")
    .addEventListener(
      "change",
      (event) => {

        const files =
          Array.from(
            event.target.files ||
            []
          );


        $("#photoList")
          .textContent =
          files.length
            ? files
                .map(
                  (file) =>
                    file.name
                )
                .join(", ")
            : "";

      }
    );


  /* RETURN FORM */

  $("#returnForm")
    .addEventListener(
      "submit",
      submitReturnForm
    );


  /* RESET */

  $("#resetReturnBtn")
    .addEventListener(
      "click",
      () => {

        $("#returnForm")
          .reset();


        state.selectedItems
          .clear();


        hideAlert(
          "#returnFormAlert"
        );


        hideAlert(
          "#returnEscalation"
        );


        $("#returnResult")
          .hidden = true;


        $("#returnAudit")
          .hidden = true;


        $("#photoUpload")
          .hidden = true;


        $("#photoList")
          .textContent = "";


        $("#escalateReturnBtn")
          .hidden = true;

      }
    );


  /* RETURN ESCALATION */

  $("#escalateReturnBtn")
    .addEventListener(
      "click",
      () => {

        escalate(
          "return",
          "Return eligibility requires manual review."
        );

      }
    );


  /* GO FROM REFUND TO RETURN */

  $("#goStartReturnBtn")
    .addEventListener(
      "click",
      () => {

        const orderNumber =
          $("#refundOrderNumber")
            .value
            .trim()
            .toUpperCase();


        const email =
          $("#refundEmail")
            .value
            .trim();


        activateTab(
          $("#tab-return")
        );


        if (orderNumber) {

          $("#returnOrderNumber")
            .value =
            orderNumber;

        }


        if (email) {

          $("#returnEmail")
            .value =
            email;

        }

      }
    );


  /* REFUND NOT RECEIVED */

  $("#refundNotReceivedBtn")
    .addEventListener(
      "click",
      () => {

        escalate(
          "refund",
          "Customer reports the refund has not been received."
        );

      }
    );


  /* REFUND ESCALATION */

  $("#refundEscalateBtn")
    .addEventListener(
      "click",
      () => {

        escalate(
          "refund",
          "Customer requested human support for refund status."
        );

      }
    );

})();